python vae_train.py
python series.py
python rnn_train.py

